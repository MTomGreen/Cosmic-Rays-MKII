package green.object;

import java.util.ArrayList;
import java.util.HashMap;

public interface CoincidenceReceiver {
	
	public abstract void receiveCoincidences(ArrayList<HashMap<String, Object>> data);

}
