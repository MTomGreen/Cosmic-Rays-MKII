package green.object;

import java.util.ArrayList;

public class Coincidence {
	
	public ArrayList<String> rawData = new ArrayList<String>();
	
	public Coincidence(int id) {
	}

}
