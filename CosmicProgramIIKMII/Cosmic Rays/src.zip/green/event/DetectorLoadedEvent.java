package green.event;

public class DetectorLoadedEvent extends Event{

}
