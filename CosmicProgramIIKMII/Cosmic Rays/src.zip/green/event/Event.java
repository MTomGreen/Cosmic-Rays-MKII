package green.event;

public class Event {

}
