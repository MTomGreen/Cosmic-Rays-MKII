package green.ui.mainWindow.component;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public abstract class Input extends JPanel {
	
	public abstract Object getInfo();

}
